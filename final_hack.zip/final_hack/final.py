import pandas as pd
from flask import Flask, render_template, request, jsonify
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

app = Flask(__name__)

# Load the dataset
data = pd.read_csv('cooking_dataset.csv')

# Prepare the data
features = data[['Recipe_Complexity', 'Ingredients', 'Chef_Experience']]
target = data['Cooking_Time']

# Split the data into training and testing sets (80% training, 20% testing)
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

# Train the linear regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Function to predict cooking time for a new recipe
def predict_cooking_time(recipe_complexity, ingredients, chef_experience):
    # Predict the cooking time
    predicted_cooking_time = model.predict([[recipe_complexity, ingredients, chef_experience]])
    return predicted_cooking_time[0]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
